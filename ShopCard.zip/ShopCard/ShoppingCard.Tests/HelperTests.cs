﻿using ShoppingCard.Constants;
using System.Linq;
using Xunit;
using Xunit.Abstractions;
using ShoppingCard.Helper;
using System.IO;
using System;

namespace ShoppingCard.Tests
{
    public class HelperTests
    {

        private readonly ITestOutputHelper _out;

        public HelperTests(ITestOutputHelper output)
        {
            this._out = output;
        }

        [Fact]
        public void FrequencyTest()
        {
            int[] num = { 0, 1, 2, 0, 6, 0, 7 };

            var indxs = Enumerable.Range(0, num.Count())
                         .Where(i => num[i] == 0)
                         .ToList();

            Assert.Equal(0, indxs[0]);
            Assert.Equal(3, indxs[1]);
            Assert.Equal(5, indxs[2]);
        }

        [Fact]
        public void PrintTest()
        {
            ShoppingCard card = new ShoppingCard(logEnable: true);
            card.Add(ProductName.milk, 10.00);
            card.Add(ProductName.bread, 1.00);
            card.GetAmount();
        }

    }
}