using ShoppingCard.Constants;
using System.Linq;
using Xunit;

namespace ShoppingCard.Tests
{
    public class BasicTests
    {
        private double breadPrice = 1.00;
        private double butterPrice = 0.8;
        private double milkPrice = 1.15;
        [Fact]
        public void ProductIsDiscountDefaultsTest()
        {
            ShoppingCard card = new ShoppingCard(logEnable: false);
            Assert.Equal((int)CardState.Empty, card.State);

            card.Add(ProductName.milk, milkPrice);
            Assert.Equal((int)CardState.Active, card.State);

            card.Add(ProductName.milk, milkPrice);
            card.Add(ProductName.bread, breadPrice);
            Assert.True(
                card.GetProductsList().
                Where(p => p.Discount != 0).ToList().Count() == 0
            );
        }

        [Fact]
        public void CardAddRemoveTest()
        {
            ShoppingCard card = new ShoppingCard(logEnable: false);
            Assert.Equal((int)CardState.Empty, card.State);

            card.Add(ProductName.milk, milkPrice);
            Assert.Equal((int)CardState.Active, card.State);
            Assert.True(card.GetProductsList().Count() == 1);

            card.Add(ProductName.bread, breadPrice);
            Assert.Equal((int)CardState.Active, card.State);
            Assert.True(card.GetProductsList().Count() == 2);

            card.Remove(1);
            Assert.Equal((int)CardState.Active, card.State);
            Assert.True(card.GetProductsList().Count() == 1);

            card.Remove(0);
            Assert.Equal((int)CardState.Empty, card.State);
            Assert.True(card.GetProductsList().Count() == 0);
        }
    }
}