﻿using ShoppingCard.Constants;
using Xunit;

namespace ShoppingCard.Tests
{
    public class FunctionalScenariosTests
    {
        private const double breadPrice = 1.00;
        private const double butterPrice = 0.8;
        private const double milkPrice = 1.15;
        [Fact]
        public void ScenarioOneTest()
        {
            ShoppingCard card = new ShoppingCard(logEnable: true);

            card.Add(ProductName.bread, breadPrice);
            card.Add(ProductName.butter, butterPrice);
            card.Add(ProductName.milk, milkPrice);

            Assert.True(card.GetAmount() == (decimal)(2.95));
        }


        [Fact]
        public void ScenarioTwoTest()
        { 
            ShoppingCard card = new ShoppingCard(logEnable: true);


            card.Add(ProductName.bread, breadPrice);
            card.Add(ProductName.bread, breadPrice);

            card.Add(ProductName.butter, butterPrice);
            card.Add(ProductName.butter, butterPrice);

            Assert.True(card.GetAmount() == (decimal)(3.10));
        }


        [Fact]
        public void ScenarioThreeTest()
        {

            ShoppingCard card = new ShoppingCard(logEnable: true);


            //// 4 milks
            card.Add(ProductName.milk, milkPrice);
            card.Add(ProductName.milk, milkPrice);
            card.Add(ProductName.milk, milkPrice);
            card.Add(ProductName.milk, milkPrice);

            Assert.True(card.GetAmount() == (decimal)(3.45));
        }

        [Fact]
        public void ScenarioFourTest()
        {
            ShoppingCard card = new ShoppingCard(logEnable: true);
    
            card.Add(ProductName.bread, breadPrice);

            card.Add(ProductName.butter, butterPrice);
            card.Add(ProductName.butter, butterPrice);


            card.Add(ProductName.milk, milkPrice);
            card.Add(ProductName.milk, milkPrice);
            card.Add(ProductName.milk, milkPrice);
            card.Add(ProductName.milk, milkPrice);
            card.Add(ProductName.milk, milkPrice);
            card.Add(ProductName.milk, milkPrice);
            card.Add(ProductName.milk, milkPrice);
            card.Add(ProductName.milk, milkPrice);

            Assert.True(card.GetAmount() == (decimal)(9.00));
        }
    }
}