﻿using ShoppingCard.Constants;
using ShoppingCard.Exceptions;
using System.Linq;
using Xunit;


namespace ShoppingCard.Tests
{
    public class StateTests
    {
        [Fact]
        public void EmptyStateTest()
        {
            ShoppingCard card = new ShoppingCard(logEnable: true);
            Assert.True(card.State == (int)CardState.Empty);
            Assert.Throws<EmptyCardRemoveException>(() => card.Remove(0));
            Assert.Throws<EmptyCardPayException>(() => card.Pay());


        }

        [Fact]
        public void PayStateTest()
        {
            ShoppingCard card = new ShoppingCard(logEnable: true);

            card.Add(ProductName.milk, 0);
            Assert.True(card.State == (int)CardState.Active);

            card.Pay();
            Assert.True(card.State == (int)CardState.Paid);
            Assert.Throws<PaidCardException>(() => card.Remove(0));
            Assert.Throws<PaidCardException>(() => card.Add(ProductName.milk, 0));
            Assert.Throws<PaidCardException>(() => card.Pay());



        }

    }
}
