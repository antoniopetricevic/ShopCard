﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ShoppingCard.Exceptions
{
    public class EmptyCardPrintException : Exception
    {
        public EmptyCardPrintException(string message) : base(message)
        {
        }

        public EmptyCardPrintException(string message, Exception innerException) : base(message, innerException)
        {
        }
    }
}
