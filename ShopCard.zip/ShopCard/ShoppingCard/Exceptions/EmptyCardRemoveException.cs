﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Runtime.ConstrainedExecution;
using System.Text;

namespace ShoppingCard.Exceptions
{


    public class EmptyCardRemoveException : Exception
    {
        public EmptyCardRemoveException(string message) : base(message)
        {
        }

        public EmptyCardRemoveException(string message, Exception innerException) : base(message, innerException)
        {
        }
    }

}
