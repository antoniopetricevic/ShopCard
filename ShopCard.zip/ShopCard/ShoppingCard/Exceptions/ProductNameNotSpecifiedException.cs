﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ShoppingCard.Exceptions
{
    public class ProductNameNotSpecifiedException : Exception
    {
        public ProductNameNotSpecifiedException(string message) : base(message)
        {
        }

        public ProductNameNotSpecifiedException(string message, Exception innerException) : base(message, innerException)
        {
        }
    }
}
