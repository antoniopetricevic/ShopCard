﻿using ShoppingCard.Constants;
using ShoppingCard.Exceptions;
using ShoppingCard.Generic;
using ShoppingCard.Model;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading;

namespace ShoppingCard
{

    public class ShoppingCard : IShoppingCard
    {

        private IList<Product> _products;
        private int _state = (int)CardState.Empty;

        public string Id { get; set; }
        public int State { get { return _state; } }

        public bool LogEnable { get; set; }
        public ShoppingCard(bool logEnable)
        {
            Id = Guid.NewGuid().ToString();
            this._products = new List<Product>();
            this.LogEnable = LogEnable;
        }

        public void Add(string productName, double price)
        {
            if (this._state == (int)CardState.Paid)
            {
                throw new PaidCardException(Message.paidCardException);
            }
            else if (productName == String.Empty)
            {
                throw new ProductNameNotSpecifiedException(Message.productNameNotSpecifiedException);
            }
            var product = new Product() { Name = productName, Price = price, FullPrice = price, Discount = 0 };

            this._products.Add(product);

            if (this._state == (int)CardState.Empty)
            {
                this._state = (int)CardState.Active;
            }
        }

        public void Remove(int index)
        {
            if (this._state == (int)CardState.Empty)
            {
                throw new EmptyCardRemoveException(Message.emptyCardRemoveException);
            }

            if (this._state == (int)CardState.Paid)
            {
                throw new PaidCardException(Message.paidCardException);
            }

            if (index > this._products.Count())
            {
                throw new System.ArgumentOutOfRangeException();
            }

            this._products.RemoveAt(index);
            if (this._products.Count() == 0)
            {
                this._state = (int)CardState.Empty;
            }
        }

        public IEnumerable<Product> GetProductsList()
        {
            return this._products;
        }

        public void Pay()
        {
            if (this._state == (int)CardState.Empty)
            {
                throw new EmptyCardPayException(Message.emptyCardNoPayException);
            }
            else if (this._state == (int)CardState.Paid)
            {
                throw new PaidCardException(Message.paidCardException);
            }

            this._state = (int)CardState.Paid;
        }


        public decimal GetAmount()
        {
            int butterAndBreadDiscount = this.getButterAndBreadDiscount();

            if (butterAndBreadDiscount > 0)
            {
                var breadIndxs = Enumerable.Range(0, this._products.Count())
                .Where(i =>
                this._products[i].Name.ToUpper() == ProductName.bread.ToUpper()).
                ToList();

                int j = 1;

                while (j <= butterAndBreadDiscount)
                {
                    if (breadIndxs[j - 1] < this._products.Count)
                    {
                        this._products[breadIndxs[j - 1]].Price = (this._products[breadIndxs[j - 1]].Price / 2);
                        this._products[breadIndxs[j - 1]].Discount = this._products[breadIndxs[j - 1]].Price - this._products[breadIndxs[j - 1]].FullPrice;

                        j++;
                    }
                    else { break; }

                }
            }

            int milkDiscount = this.getMilkDiscount();
            if (milkDiscount > 0)
            {
                var milkIndxs = Enumerable.Range(0, this._products.Count())
                .Where(i =>
                this._products[i].Name.ToUpper() == ProductName.milk.ToUpper()).
                ToList();

                int j = 1;
                while (j <= milkDiscount)
                {
                    if (milkIndxs[j - 1] < this._products.Count)
                    {
                        this._products[milkIndxs[j - 1]].Price = 0;
                        this._products[milkIndxs[j - 1]].Discount = this._products[milkIndxs[j - 1]].Price - this._products[milkIndxs[j - 1]].FullPrice;

                        j++;
                    }
                    else { break; }


                }

            }

            var amount = this._products.Select(p => new { price = p.Price })
                .ToList().Sum(a => (decimal)a.price);

            if (this.LogEnable)
            {
                var logger = new Helper.FileLogger();
                logger.Log(this.Print(amount));
            }

            return amount;
        }

        public string Print(decimal amount)
        {
            string billPrint = $"Card id: { this.Id}\n" +
            $"Time: {DateTime.Now.ToString("MM/dd/yyyy HH:mm")}" + "\n" +
            "=======================================================================" + "\n" +
            "Details:" + "\n";

            foreach (var prod in this._products)
            {
                billPrint += $"Product: {prod.Name} \t" +
                    $"Price: {prod.Price:0.00}\tFull Price: {prod.FullPrice:0.00}\tDiscount: {prod.Discount:0.00}" +
                    "\n";
            }

            billPrint += "=======================================================================" + "\n"
                + $"Total Sum: \t\t\t\t\t\t {amount:0.00}\n"
            + "=======================================================================" + "\n\n\n";
            return billPrint;
        }

        private int getMilkDiscount()
        {
            var milkCount = this._products.Where(p => p.Name.ToUpper() == ProductName.milk.ToUpper()).Count();
            if (milkCount >= DiscountQuantity.milk)

            {
                return (int)(milkCount / DiscountQuantity.milk);
            }
            return 0;
        }

        private int getButterAndBreadDiscount()
        {
            int butterCount = this._products.Where(p => p.Name == ProductName.butter).Count();
            if (butterCount >= DiscountQuantity.butter)
            {
                return (int)(butterCount / 2);
            }
            return 0;
        }
    }
}