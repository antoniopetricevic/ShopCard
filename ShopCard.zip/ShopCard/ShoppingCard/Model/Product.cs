﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ShoppingCard.Model
{
    public class Product
    {
        public string Name { get; set; }
        public double Price { get; set; }
        public double FullPrice { get; set; }
        public double Discount { get; set; }
    }
}
