﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ShoppingCard.Constants
{
    internal static class DiscountQuantity
    {
        internal const int milk = 3;
        internal const int butter = 2;
    }




    public enum CardState
    {
        Empty = 0,
        Active = 1,
        Paid = 2
    }
}
