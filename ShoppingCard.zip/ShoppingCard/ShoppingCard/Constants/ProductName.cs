﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ShoppingCard.Constants
{
    public static class ProductName
    {
        public const string milk = "Milk";
        public const string butter = "Butter";
        public const string bread = "Bread";

    }



}
