﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ShoppingCard.Constants
{
    internal static class Message
    {
        internal static string emptyCardRemoveException =
            @"Cannot remove item on empty card!";

        internal static string paidCardException =
            @"Cannot operate on paid cart!";

        internal static string productNameNotSpecifiedException =
            @"Product name must be specified!";

        internal static string productToRemoveNotFound =
            @"Product cannot be found!";

        internal static string emptyCardNoPayException =
         @"Empty card cannot be billed!";

        internal static string emptyCardPrintException =
        @"Cannot print empty card!";

    }
}
