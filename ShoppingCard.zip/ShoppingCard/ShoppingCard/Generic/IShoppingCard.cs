﻿using System;
using System.Collections.Generic;
using System.Text;
using ShoppingCard.Model;

namespace ShoppingCard.Generic
{
    interface IShoppingCard
    {
        void Add(string productName, double price);
        void Remove(int index);
        void Pay();

        IEnumerable<Product> GetProductsList();

        decimal GetAmount();

    }
}
