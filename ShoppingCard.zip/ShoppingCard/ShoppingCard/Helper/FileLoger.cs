﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace ShoppingCard.Helper
{
    internal abstract class LogBase
    {
        public abstract void Log(string message);
    }

    internal class FileLogger : LogBase
    {

        private string _filePath;
        public FileLogger()
        {
            _filePath = Path.Combine(Environment.CurrentDirectory,
                @"shoppingcard.log");

            if (!File.Exists(_filePath))
            {
                File.Create(_filePath);
            }
        }
        public override void Log(string message)
        {
            using (StreamWriter streamWriter = File.AppendText(_filePath))
            {
                streamWriter.WriteLine(message);
                streamWriter.Close();
            }
        }
    }
}
