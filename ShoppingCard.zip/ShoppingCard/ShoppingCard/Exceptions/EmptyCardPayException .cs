﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ShoppingCard.Exceptions
{
    public class EmptyCardPayException :Exception 
    {
        public EmptyCardPayException (string message) : base(message)
        {
        }

        public EmptyCardPayException (string message, Exception innerException) : base(message, innerException)
        {
        }
    }
}
