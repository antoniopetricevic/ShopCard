﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ShoppingCard.Exceptions
{
    public class ProductToRemoveNotFoundException : Exception
    {
        public ProductToRemoveNotFoundException(string message) : base(message)
        {
        }

        public ProductToRemoveNotFoundException(string message, Exception innerException) : base(message, innerException)
        {
        }
    }
}
