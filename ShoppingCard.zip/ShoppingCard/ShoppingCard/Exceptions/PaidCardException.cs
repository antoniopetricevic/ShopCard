﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ShoppingCard.Exceptions
{
    public class PaidCardException : Exception
    {
        public PaidCardException(string message) : base(message)
        {
        }

        public PaidCardException(string message, Exception innerException) : base(message, innerException)
        {
        }
    }
}
